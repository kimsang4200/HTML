// modules
var http = require('http');
var url = require('url');
var fs = require('fs');
var path = require('path');
var express = require('express');
var mysql = require('mysql');
var session = require('express-session');
var fileStore = require('session-file-store')(session);
var bodyParser = require('body-parser');
var bcrypt = require('bcrypt-nodejs');

var app = express();
var router = express.Router();

// http request, response
app.use(function(req, res, next) {
	var date = new Date();
	console.log(">> reqURL: " + req.originalUrl + " [" + date + "] " + req.ip);
	next();
});

app.use(session({
	secret: 'keyboard cat',
	resave: false,
	saveUninitialized: true,
	store: new fileStore({logFn: function(){}})
}));

app.set('views', path.join('/home/test'));
app.set('view engine', 'ejs');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

var game_search_db_connect = mysql.createConnection({
	host: 'localhost',
	port: '3456',
	user: 'first_user',
	password: 'tj0123456',	
	database: 'first_db'
});

game_search_db_connect.connect();

// web server
app.get('/first/', function(req, res) {
	if (req.session.logined) {
		res.render('index');
	} else {
		res.render('index', { userId: req.session.userId });
	}
});

app.get('/first/login', function(req, res) {
	if (req.session.logined) {
		res.render('index', { userId: req.session.userId });
	} else {
		res.render('login');
	}
});

app.post('/first/login', function(req, res) {
	var userId = req.body['userId'];
	var userPw = req.body['userPw'];
	
	game_search_db_connect.query(
		'select id, password from users'
		+ ' where id=\"' + userId + '\";', function (err, rows, fields) {
			if (!err) {
				if (rows.length) {
					bcrypt.compare(userPw, rows[0].password, function(error, response) {
						if (response) {
							if (!req.session.logined) {
								req.session.logined = true;
								req.session.userId = userId;
								res.render('index', { userId: req.session.userId });
							} else {
								res.render('index');
							}
		
						} else {
							res.send('<script>alert("비밀번호를 확인하세요."); location.href="/first/login"; </script>');
						}
					});
				} else {
					res.send('<script>alert("아이디와 비밀번호를 확인하세요."\); location.href="/first/login"; </script>');
				}
			} else {
				console.log('users db error >> ');
				console.log(err);
				res.redirect('/first');
			}
		});
	});

app.get('/first/logout', function(req, res) {
	req.session.destroy();
	res.redirect('/first');
});

app.get('/first/register', function(req, res) {
	res.render('register');
});

app.post('/first/register', function(req, res) {
	var userId = req.body['userId'];
	var userPw = req.body['userPw'];
	var userPwAg = req.body['userPwAg'];
	
	// 아이디는 영 문대소문자 또는 숫자로 되어야 하며, 길이는 4~12자
	var regExpId = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

	// 비밀번호는 최소 8자, 대문자 하나 이상, 소문자 하나 및 숫자 하나
	var regExpPw =  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;

	// check to id, password, password again value
	if (typeof userId !== "undefined" &&
	    typeof userPw !== "undefined" &&
	    typeof userPwAg !== "undefined") {
		// check to id regular expression
		if (!regExpId.test(userId)) {
			res.send('<script>alert("올바른 이메일을 입력하세요."\); location.href="/first/register"; </script>');
			return;
		}

		// check to equal userPw and userPwAg
		if (userPw != userPwAg) {
			res.send('<script>alert("비밀번호를 맞게 입력했는지 확인하십시오."\); location.href="/first/register"; </script>');
			return;
		}

		// check to pw regular expression
		if (!regExpPw.test(userPw)) {
			res.send('<script>alert("비밀번호는 대문자, 소문자, 숫자를 모두  1회 이상 사용하여  8자리 이상 입력하십시오."\); location.href="/first/register"; </script>');
			return;
		}

		var overLap = false;
		// id 중복검사
		game_search_db_connect.query(
			'select * from users where id=?',
			[userId], function(err, rows) {
			if (typeof rows.length === "undefined") {
				return;
			}

			if (rows.length) {
				res.send('<script>alert(\"이미 가입되어 있는 이메일입니다."\); location.href="/first/login"; </script>');
				overLap = true;
			}
		});
		
		if (overLap)
			return;
		else {
			// 비밀번호 암호화
			bcrypt.hash(userPw, null, null, function(err, hash) {
				if (!err) {
					userPw = hash;
					game_search_db_connect.query('insert into users values (?, ?)', [userId, userPw], function (err, rows, fields) {
						if (!err) {
							res.send('<script>alert(\"' + userId + '님 가입을 축하합니다!"\); location.href="/first/login"; </script>');
						} else {
							console.log("register error >> " + err);
						}
					});
				} else {
					console.log("create user password hash >> " + err); 
				}
			});
		}
	} else {
		res.send('<script>alert("아이디, 비밀번호, 비밀번호 확인을 입력하세요."\); location.href="/first/register"; </script>');	
	}
});

app.get('/first/board/:id', function(req, res) {
	var id;
	try {
		id = parseInt(req.params.id);
	} catch (err) {
		res.send("<script>alert('잘못된 주소로 접근했습니다.');</script>");
		return;
	}
	var loadOnePageLimit = 10; // 10개의 글
	var start = loadOnePageLimit * id - loadOnePageLimit; // 테이블에 어느 시작부터 가져올 것인지 정함
	
	var contentRows;
	var contentCount;

	game_search_db_connect.query('select no, title, author, date_format(date, "%Y-%m-%d %T") "date", click from board order by no desc limit ' + start + ', ' + loadOnePageLimit, function(err, rows, fields) {
		if (!err) {	
			contentRows = rows;

			// 게시판의 데이터 수를 세서, 목록화하기 위함
			game_search_db_connect.query('select count(*) from board', function (err, rows, fields) {
				if (!err) {
					contentCount = rows;

					var sendData = [ contentRows, contentCount, start ];	
					res.render('board', { data: sendData });

				} else {
					console.log("board error >> " + err);
					return;
				}
			});

		} else {
			console.log("board print page error >> " + err);
			return;
		}
	});
});

app.get('/first/board_new', function(req, res) {
	if (req.session.logined) {
		res.render('board_new');
	} else {
		res.send("<script>alert('로그인해야 이용할 수 있습니다.'); location.href='/first/login'; </script>");
	}
});

app.get('/first/board/read/:id', function(req, res) {
	// 글쓴 것 보기 + 댓글 조회
	var id;
	try {
		id = parseInt(req.params.id);
	} catch (err) {
		res.send("<script>alert('잘못된 주소로 접근했습니다.');</script>");
		return;
	}

	var isRight = true; // 올바른 경로로 접근했는가?
	// 조회수 늘리기
	game_search_db_connect.query('update board set click = click + 1 where no = ' + id, function(err, rows, fields) {
		if (err) {
			isRight = false;
			res.send('<script> alert("잘못된 경로로 접근했습니다."); location.href = "/first/board"; </script>');
		}
	});

	if (!isRight)
		return;

	// 글 보여주기
	game_search_db_connect.query('select no, title, content, author, date_format(date, "%Y-%m-%d %T") "date", click from board where no = ' + id, function(err, board, fields) {
		if (!err) {
			// 댓글 보여주기
			game_search_db_connect.query('select no, content, author, date_format(date, "%Y-%m-%d %T") "date", like_num, unlike_num, board_no from comment where board_no = ' + id, function(err, comments, fields) {
				if (!err) {
					res.render('board_read', { data: board, userSessionId: req.session.userId, comment: comments });
				} else {
					console.log('board comment read error >> ' + err);
				}
			});
		} else {
			console.log('board read error >> ' + err);
		}
	});
});

function getTimeStamp() {
	var d = new Date();
	var s = leadingZeros(d.getFullYear(), 4) + '-' +
		leadingZeros(d.getMonth() + 1, 2) + '-' +
		leadingZeros(d.getDate(), 2) + ' ' +
		leadingZeros(d.getHours(), 2) + ':' +
		leadingZeros(d.getMinutes(), 2) + ':' +
		leadingZeros(d.getSeconds(), 2);
	
	return s;
}

function leadingZeros(n, digits) {
	var zero = '';
	n = n.toString();

	if (n.length < digits) {
		for (i = 0; i < digits - n.length; ++i) {
			zero += '0';
		}
	}

	return zero + n;
}


// 댓글
app.post('/first/board/read/write_comment', function(req, res) {
	var content = req.body['content'];
	var author = req.body['author'];
	var date = getTimeStamp();
	var like_num = 0;
	var unlike_num = 0;
	var board_no = req.body['board_no'];

	if (content == "") {
		res.send('<script>alert("댓글을 입력하세요."); history.back();</script>');
		return;
	}

	if (content.length > 299) {
		res.send('<script>alert("댓글은 300자까지만 입력가능합니다.");</script>');
		return;
	}

	game_search_db_connect.query('insert into comment (content, author, date, like_num, unlike_num, board_no) values (?, ?, ?, ?, ?, ?)', [content, author, date, like_num, unlike_num, board_no], function (err, rows, fields) {
		if (!err) {
			res.send('<script>location.href = "/first/board/read/' + board_no  + '"</script>');
		} else {
			res.send('<script>alert("내용을 입력하십시오.");</script>');
		}
	});
});

app.get('/first/board/delete_comment/:id', function(req, res) {
	var id;
	try {
		id = parseInt(req.params.id);
	} catch (err) {
		res.send("<script>alert('잘못된 주소로 접근했습니다.');</script>");
		return;	
	}

	game_search_db_connect.query('select author, board_no from comment where no = ' + id, function(err, rows, fields) {
		if (!err && typeof rows !== "undefined") {
			if (rows[0]['author'] == req.session.userId) {
				game_search_db_connect.query('delete from comment where no = ' + id, function (err, data, fields) {
					if (!err) {
						res.send('<script>alert("삭제되었습니다."); location.href="/first/board/read/' + rows[0]['board_no'] + '"; </script>');
					}
				});
			} else {
				res.send('<script>alert("삭제할 수 없습니다.");</script>');
			}
		}
	});
});

app.get('/first/board/delete/:id', function(req, res) {
	var id;
	try {
		id = parseInt(req.params.id);
	} catch (err) {
		res.send("<script>alert('잘못된 주소로 접근했습니다.');</script>");
		return;
	}

	game_search_db_connect.query('select author from board where no = ' + id, function(err, rows, fields) {
		if (!err && typeof rows !== "undefined") {
			if (rows[0]['author'] == req.session.userId) {
				game_search_db_connect.query('delete from board where no = ' + id, function (err, data, fields) {
					if (!err) {
						res.send('<script>alert("삭제되었습니다."); location.href="/first/board/1"; </script>');
					}
				});
			} else {
				res.send('<script>alert("삭제할 수 없습니다.");</script>');
			}
		}
	});
});

app.post('/first/board_new', function(req, res) {
	var title = req.body['title'];
	var content = req.body['content'];
	var author =  req.session.userId;
	var date = getTimeStamp();
	var click = 1;

	// title, content 글자 수 제한 검사
	if (title == "" || content === "") {
		res.send('<script>alert("제목과 글을 입력하세요."); location.href="/first/board_new";</script>');
		return;
	}

	if (title.length > 99 || typeof content > 999) {
		res.send('<script>alert("제목은 100자 미만, 글은 1000자 미만만 입력가능합니다.");</script>');
		return;
	}

	game_search_db_connect.query('insert into board(title, content, author, date, click) values (?, ?, ?, ?, ?)', [title, content, author, date, click], function (err, rows, fields) {
		if (!err) {
			res.send('<script>location.href="/first/board/1"; </script>');
		} else {
			console.log("board error >> " + err);
		}
	});
});

app.get('/first/img/:id', function(req, res) {
		var extension;
		if (typeof req.params.id !== "undefined") {
			extension = req.params.id.split('.')[1];
		} else {
			return;
		}

	        fs.readFile('/home/test/' + req.params.id, function(err, data) {
			if (!err) {
				res.writeHead(200, { 'Context-Type' : 'image/'+ extension });
				res.write(data);
				res.end();
				return;
			} else {
				res.status(404).send('Not Found');
			}
		});
});

app.get('/first/food', function(req, res) {
	res.render('food');	
});


// --------------------------------------

var server = app.listen(80, function() {
	console.log('connected 80 port!');
});

var io = require('socket.io').listen(server);

app.get('/socket.io/socket.io.js', function(req, res) {
	fs.readFile('/root/web/www/node_modules/socket.io-client/dist/socket.io.js', function(err, data) {
		res.writeHead(200, {'Content-Type': 'text/javascript'});
		res.write(data);
		res.end();
	});
});

io.on('connection', (socket) => {
	socket.on('addUser', function(name) {		
		socket.name = name; // 이름 저장

		io.sockets.emit('connect chat', '[' + getTimeStamp() + '] ' + name + '님이 들어오셨습니다.');
	});

	socket.on('disconnect', function(name){
		socket.broadcast.emit('disconnect chat', '[' + getTimeStamp() + '] ' + socket.name + '님이 나가셨습니다.');
	});

	socket.on('send message', function(name,text){
		var msg = name + '[' + getTimeStamp() + ']'  + ' : ' + text;
		io.emit('receive message', msg);
	});
});


app.get('/first/chat', function(req, res) {
	if (req.session.logined) {
		// chatting server
		var userid = req.session.userId;
		res.render('chat', { userId: userid });
	} else {
		res.send('<script>alert("로그인해야 이용할 수 있습니다."); location.href="/first/login"; </script>');
	}
});
